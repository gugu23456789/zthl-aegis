# Copyright (c) 2026 Pu Junhan
# SPDX-License-Identifier: MulanPSL-2.0
# Project: ZTHL-Harness
# Repository: https://github.com/zthl-harness/zthl-bashpy-migrate

"""cli.py — bashpy-migrate command line entry.

Subcommands:
  analyze   L1: bash 函数依赖图 / 副作用清单 / 迁移边界建议
  verify    L2: 语义等价（baseline 固化快照 / output 对比 / artifact 产物对比 / dry-run 零副作用）
  audit     L3: 死代码三关 + 写入守卫审查 + 仓库断言挂载 + LLM 兜底（可选）
"""
import argparse
import json
import sys
from typing import List, Optional

from . import __version__
from .analyze import analyze as l1_analyze
from .audit import (bomb_scan, dead_code, llm_explain, mount_assertions,
                    python_module_deadcode, shellcheck_scan, write_guard_check)
from .triage import triage as run_triage
from .verify import (capture_baseline, dry_run_check, load_normalizer, loads_json,
                     verify, verify_artifact)


def _emit(obj: dict) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2))


def _cmd_analyze(args) -> int:
    with open(args.script, encoding="utf-8", errors="replace") as f:
        src = f.read()
    report = l1_analyze(src)
    _emit(report)
    return 0


def _cmd_verify(args) -> int:
    if args.baseline_capture:
        result = capture_baseline(_split_cmd(args.cmd), args.out)
        _emit(result)
        return 0
    if args.dry_run:
        result = dry_run_check(_split_cmd(args.cmd), args.state)
        _emit(result)
        return 0 if result["state_unchanged"] else 1
    if args.artifact_baseline or args.artifact_output:
        # artifact 产物对比：归一化器由调用方注入（引擎不内置业务规则）
        if not (args.artifact_baseline and args.artifact_output):
            print("verify: --artifact-baseline 与 --artifact-output 必须同时给出",
                  file=sys.stderr)
            return 2
        with open(args.artifact_baseline, encoding="utf-8", errors="replace") as f:
            baseline = loads_json(f.read())
        with open(args.artifact_output, encoding="utf-8", errors="replace") as f:
            output = loads_json(f.read())
        normalizer = None
        if args.normalizer:
            try:
                normalizer = load_normalizer(args.normalizer)
            except (ValueError, ImportError) as e:
                print("verify: 归一化器注入失败：%s" % e, file=sys.stderr)
                return 2
        try:
            result = verify_artifact(baseline, output, normalizer,
                                     _load_whitelist_opt(args.whitelist))
        except ValueError as e:
            print("verify: %s" % e, file=sys.stderr)
            return 2
        _emit(result)
        return 0 if result["equivalent"] else 1
    # semantic equivalence: baseline vs output
    with open(args.baseline, encoding="utf-8", errors="replace") as f:
        baseline = loads_json(f.read())
    with open(args.output, encoding="utf-8", errors="replace") as f:
        output = loads_json(f.read())
    result = verify(baseline, output, _load_whitelist_opt(args.whitelist))
    _emit(result)
    return 0 if result["equivalent"] else 1


def _load_whitelist_opt(path: Optional[str]):
    """契约改进白名单（两条 verify 路径共用；缺省 = None）。"""
    if not path:
        return None
    from .verify import load_whitelist
    return load_whitelist(path)


def _cmd_audit(args) -> int:
    with open(args.script, encoding="utf-8", errors="replace") as f:
        src = f.read()
    report: dict = {}
    if args.dead_code:
        entries = [e.strip() for e in args.entry.split(",") if e.strip()]
        report["dead_code"] = dead_code(src, entries)
    if args.write_fns:
        fns = [e.strip() for e in args.write_fns.split(",") if e.strip()]
        report["write_guard"] = write_guard_check(src, fns)
    if args.bomb:
        report["bomb_scan"] = bomb_scan(src)
        # 行级告警 + 可排序载荷清单（2026-11-04）：前者巡检，后者决定先拆哪块
        from .inventory import scan_inline
        report["inline_inventory"] = scan_inline(src)
    if args.shellcheck:
        report["shellcheck_scan"] = shellcheck_scan(src, strict=args.strict)
    if args.py_deadcode:
        report["python_module_deadcode"] = python_module_deadcode(src)
    if args.py_lint:
        # 2026-11-04：ruff 子集（E722 裸 except / F841 未使用局部变量）
        from .audit import python_lint
        report["python_lint"] = python_lint(src)
    if args.explain or args.triage:
        items = _collect_items(report)
        if args.explain:
            report["llm"] = llm_explain(items, args.api_key)
        if args.triage:
            # 分诊模型（advisory）：只影响排序/分组，**不改判定、不改 exit code**
            report["triage"] = run_triage(items, args.api_key)
    if args.mount:
        # 仓库级断言挂载（只认退出码）：失败即 L3 退出码非零，但不中断报告输出
        report["mounted"] = mount_assertions(args.mount, args.mount_timeout)
    exit_code = 1 if report.get("mounted", {}).get("failed") else 0
    if args.format == "sarif":
        # SARIF 2.1.0（2026-11-04）：GitHub code scanning / GitLab SAST / SARIF Viewer 通用
        from .sarif import to_sarif
        _emit(to_sarif(report, args.script, __version__))
        return exit_code
    _emit(report)
    return exit_code


def _split_cmd(cmd: str) -> List[str]:
    """Split a shell-ish command string into argv (shlex, no shell=True)."""
    import shlex
    return shlex.split(cmd)


def _collect_items(report: dict) -> List[dict]:
    """从各检测段收集疑点（candidates / issues / groups 展平）—— explain 与 triage 共用。"""
    items: List[dict] = []
    for sec in report.values():
        if not isinstance(sec, dict):
            continue
        items.extend(sec.get("candidates", sec.get("issues", [])))
        for group in (sec.get("groups") or {}).values():
            items.extend(group)
    return items


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="bashpy-migrate",
        description="Deterministic bash → Python migration verification engine")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    a = sub.add_parser("analyze", help="L1: bash 函数结构/副作用/迁移边界")
    a.add_argument("--script", required=True, help="bash script path")
    a.set_defaults(func=_cmd_analyze)

    v = sub.add_parser("verify", help="L2: 语义等价 / 固化快照 / dry-run 零副作用")
    v.add_argument("--baseline-capture", action="store_true",
                   help="固化 bash 版快照: verify baseline --cmd ... --out ...")
    v.add_argument("--cmd", help="命令串（baseline-capture / dry-run 用）")
    v.add_argument("--out", help="基线输出文件")
    v.add_argument("--baseline", help="固化基线 JSON 文件")
    v.add_argument("--output", help="Python 版输出 JSON 文件")
    v.add_argument("--whitelist", help="契约改进白名单 JSON")
    v.add_argument("--dry-run", action="store_true",
                   help="dry_run 零副作用检查: verify --dry-run --cmd ... --state ...")
    v.add_argument("--state", help="state 文件（dry-run 检查前后 hash 对比）")
    v.add_argument("--artifact-baseline", help="产线基线产物 JSON（artifact 对比）")
    v.add_argument("--artifact-output", help="产线候选产物 JSON（artifact 对比）")
    v.add_argument("--normalizer", metavar="MODULE:FUNCTION",
                   help="产物归一化器（调用方注入，如 gk_monitor_fixture:_norm）")
    v.set_defaults(func=_cmd_verify)

    au = sub.add_parser(
        "audit",
        help="L3: 死代码三关 + 写入守卫 + 炸弹标记 + shellcheck TOP 子集 + Python 模块级死代码 + LLM 兜底")
    au.add_argument("--script", required=True, help="bash 或 Python 源码路径")
    au.add_argument("--dead-code", action="store_true", help="跑死代码三关")
    au.add_argument("--entry", default="main", help="生产入口函数（逗号分隔）")
    au.add_argument("--write-fns", default="_state_write,_write_state",
                    help="写入函数名（逗号分隔）")
    au.add_argument("--bomb", action="store_true",
                    help="炸弹标记扫描（python3 内联 / stderr 吞错 / 危险命令）")
    au.add_argument("--shellcheck", action="store_true",
                    help="shellcheck TOP 子集扫描（sc2086/sc2164/sc2181/sc2034/sc2155，零依赖确定性移植）")
    au.add_argument("--strict", action="store_true",
                    help="启用分级建议规则（当前：SC2046 未引号命令替换；实测多为刻意的 for 分词）")
    au.add_argument("--py-deadcode", action="store_true",
                    help="Python 模块级死代码扫描（AST 未使用 import/函数）")
    au.add_argument("--py-lint", action="store_true",
                    help="Python lint 子集（ruff 移植：E722 裸 except / F841 未使用局部变量）")
    au.add_argument("--explain", action="store_true", help="LLM 解释（可选）")
    au.add_argument("--triage", action="store_true",
                    help="分诊模型（advisory：只给排序/处置建议，不改判定与退出码）")
    au.add_argument("--api-key", default=None, help="LLM API key（缺省降级人工审查）")
    au.add_argument("--mount", action="append", metavar="CMD",
                    help="挂载仓库级断言命令（可重复；rc=0 通过，任一失败则退出码非零）")
    au.add_argument("--mount-timeout", type=int, default=120,
                    help="单条挂载断言超时秒数（默认 120）")
    au.add_argument("--format", choices=("json", "sarif"), default="json",
                    help="输出格式：json（默认）/ sarif（SARIF 2.1.0，供 CI 代码扫描平台消费）")
    au.set_defaults(func=_cmd_audit)
    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
